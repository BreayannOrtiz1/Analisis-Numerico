# Hello, world!
#
# This is an example function named 'hello'
# which prints 'Hello, world!'.
#
# You can learn more about package authoring with RStudio at:
#
#   http://r-pkgs.had.co.nz/
#
# Some useful keyboard shortcuts for package authoring:
#
#   Build and Reload Package:  'Ctrl + Shift + B'
#   Check Package:             'Ctrl + Shift + E'
#   Test Package:              'Ctrl + Shift + T'

rm(list = ls())
require(readxl)


## Ajuste Datos proyecto VIH ##


# Lectura del archivo
datos<-read_excel("C:/Users/Breayann/Downloads/Analisis Nimerico/Proyecto/datosVIH.xlsx")


# El modelo exponencial tiene la siguinete forma
# y(x) = b * e ^(a*x)
newdatos<-data.frame(datos[1:nrow(datos),1],log(datos[1:nrow(datos),2]))
Regrecion <- lm(Y ~ X, data=newdatos)

# Valor de  a
a=coefficients(Regrecion)[2]
print(a)
# Valor de b
B=exp(coefficients(Regrecion)[1])
b=exp(B)
print(b)

# Fraccion Inmortal
DDY=as.data.frame(datos[,2])
DY=as.numeric(DDY[,1])
Si=min(DY)
print(Si)

# Funcion que ajusta los datos
FuncionApro<- function(t){Si+(1-Si)*exp(a*t)}
tp=seq(0,272,16)

# Convertir a numericos los datos para procesarlos
xpolframe=as.data.frame(datos[1])
xpol=as.numeric(xpolframe[,1])

ypolframe=as.data.frame(datos[2])
ypol=as.numeric(ypolframe[,1])

## Spline que se ajusta los datos
Spline=smooth.spline(xpol,ypol)

## Datos Relevantes

# Tiempo promedio de supervivencia, en semanas

aux1=0;
for(i in 1:length(ypol)){

  if(ypol[i]>=0.5){
    aux1=aux1+1
  }
}
Tpromedio=xpol[aux1];
print(Tpromedio)

# Supervivencia de vida media, en semanas

Tvmedia=(log(2)/abs(a))/2;
print(Tvmedia)

# Graficas

#Datos
plot(datos,xlim=c(0,max(datos[,1])),ylim=c(0,1),main="Fraccion de Supervivencia", ylab="Fraccion de Supervivencia",xlab="Tiempo en semanas",col="blue",lwd=2)
grid(10, 10, lwd = 2) # grid only in y-direction
lines(tp,FuncionApro(tp),col="green",lwd=2)
lines(Spline,col="red",lwd=2)
legend("topright",col=c("blue","green","red"),legend =c("Datos Reales","Ajuste modelo exponencial","Spline"), lwd=0.7, bty = "o")
#
